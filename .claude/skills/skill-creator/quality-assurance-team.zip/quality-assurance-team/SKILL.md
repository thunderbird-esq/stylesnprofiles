---
name: quality-assurance-team
description: This skill provides comprehensive quality assurance for Aseprite textbook generation, including content validation, design compliance, technical testing, and period accuracy verification to ensure 1996 Klutz Press standards are met.
---

# Quality Assurance Team

## Overview

This skill delivers comprehensive quality assurance for Aseprite textbook generation, specializing in content validation, design compliance verification, technical testing, and 1996 Klutz Press period accuracy. It ensures all deliverables meet educational, aesthetic, and technical quality standards.

## Core Capabilities

### 1. Content Quality Validation
- **Educational Standards** - Age-appropriateness, reading levels, learning objectives
- **1996 Period Accuracy** - Cultural references, terminology, technological context
- **Content Consistency** - Style, tone, and educational progression
- **Fact-Checking** - Technical accuracy and educational validity

### 2. Design Compliance Verification
- **70/20/10 Color Distribution** - Automated color ratio validation
- **Layout Standards** - Safe zones, spine compliance, typography rules
- **Visual Hierarchy** - Information design and learning effectiveness
- **Print Simulation** - Authentic 1990s print effect validation

### 3. Technical Quality Testing
- **Performance Validation** - Load testing, memory usage, processing speed
- **Compatibility Testing** - Cross-platform, format validation
- **Integration Testing** - API integration, data flow verification
- **Security Assessment** - Data protection, privacy compliance

### 4. User Experience Validation
- **Educational Effectiveness** - Learning outcome validation
- **Age-Appropriateness** - Content complexity and engagement
- **Accessibility Compliance** - Visual readability, usability standards
- **Cultural Sensitivity** - Content appropriateness and inclusivity

## QA Workflow

### Validation Pipeline
```python
class QualityValidator:
    def validate_workbook(self, workbook_spec):
        results = {
            'content_quality': self.validate_content(workbook_spec),
            'design_compliance': self.validate_design(workbook_spec),
            'technical_quality': self.validate_technical(workbook_spec),
            'user_experience': self.validate_ux(workbook_spec)
        }
        return ValidationReport(results)
```

## Communication Protocols
- **[QA] [STATUS]** - QA testing progress and results
- **[QA] [ISSUE]** - Quality defects and compliance failures
- **[QA] [HANDOFF]** - Validated deliverables ready for production
- **[QA] [QUERY]** - Clarification requests on requirements

## Resources

### scripts/
- **content_validator.py** - Educational content quality assessment
- **design_compliance_checker.py** - Klutz Press standards validation
- **technical_tester.py** - Performance and compatibility testing
- **period_accuracy_validator.py** - 1996 authenticity verification

### references/
- **quality_standards.md** - Complete QA criteria and thresholds
- **test_procedures.md** - Detailed testing methodologies
- **compliance_guidelines.md** - Klutz Press and educational standards

## Usage Guidelines
Use this skill when validating workbook content, verifying design compliance, testing technical functionality, or ensuring period accuracy for 1996 Klutz Press authenticity.