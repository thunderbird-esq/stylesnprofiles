---
name: communication-protocols
description: This skill provides standardized communication protocols, message formats, and coordination patterns for agent teams working on Aseprite textbook generation, ensuring token-efficient and consistent inter-agent communication.
---

# Communication Protocols

## Overview

This skill establishes standardized communication protocols for agent teams, providing token-efficient message formats, status reporting structures, and coordination patterns that minimize redundant information exchange while maintaining clear communication channels between parallel working teams.

## Core Communication Standards

### 1. Message Format Structure
All inter-agent communications follow this standardized format:

```
[TEAM_CODE] [MESSAGE_TYPE] [PRIORITY] [TIMESTAMP] : [CONTENT]

Examples:
[CG] [STATUS] [NORMAL] [14:30:25] : Page 5 content generation complete
[VD] [QUERY] [HIGH] [14:31:02] : Require color palette for page 5
[QA] [ISSUE] [CRITICAL] [14:32:15] : Font validation failed on page 5
[TI] [UPDATE] [NORMAL] [14:33:00] : Image processing pipeline ready
```

### 2. Team Codes
- **CG** - Content Generation Team
- **VD** - Visual Design Team
- **TI** - Technical Implementation Team
- **QA** - Quality Assurance Team
- **OR** - Orchestrator

### 3. Message Types
- **STATUS** - Progress updates and completion reports
- **QUERY** - Information requests and clarifications
- **ISSUE** - Problems, errors, or blockers
- **UPDATE** - State changes and availability notifications
- **HANDOFF** - Task completion and delivery notifications
- **REQUEST** - Resource or action requests
- **CONFIRM** - Acknowledgments and confirmations

### 4. Priority Levels
- **CRITICAL** - Immediate attention required, blocking progress
- **HIGH** - Urgent, affecting timeline or quality
- **NORMAL** - Standard priority, routine communications
- **LOW** - Informational, can be processed asynchronously

## Communication Patterns

### 1. Status Reporting Pattern
**Frequency:** Every 5 iterations or on milestone completion
**Format:** Structured progress update with metrics

```
[TEAM] [STATUS] [NORMAL] [TIME] : PROGRESS_UPDATE
Pages: X/Y complete | Quality: Z% | ETA: N minutes | Issues: none
```

### 2. Query-Response Pattern
**Response Time:** Within 2 iterations for HIGH/CRITICAL, 5 for NORMAL
**Format:** Clear question with context requirements

**Query Example:**
```
[VD] [QUERY] [HIGH] [TIME] : COLOR_PALETTE_REQUEST
Need page 5 color scheme (70/20/10 distribution) - Nickelodeon theme
Context: Illustration of pixel art tools, targeting age 8-12
```

**Response Example:**
```
[CG] [RESPONSE] [HIGH] [TIME] : COLOR_PALETTE_PROVIDED
Palette: Primary(red/blue/yellow)-70%, Accent(orange)-20%, Theme(green)-10%
Reference: See assets/palettes/nickelodeon_page5.yaml
```

### 3. Issue Escalation Pattern
**Escalation Levels:** Team → Orchestrator → User
**Response Requirements:** Immediate acknowledgment within 1 iteration

```
[TEAM] [ISSUE] [CRITICAL] [TIME] : BLOCKING_ERROR_DESCRIPTION
Impact: Timeline delay of N minutes | Dependencies: X,Y,Z teams affected
Suggested_solution: [Brief proposed approach]
```

### 4. Handoff Pattern
**Requirements:** Complete deliverable with validation status
**Documentation:** Include file locations and quality metrics

```
[TEAM] [HANDOFF] [NORMAL] [TIME] : DELIVERABLE_COMPLETE
Deliverable: Page X content package | Location: outputs/pages/page_X/
Validation: All QA checks passed | Metrics: word_count, reading_level, etc.
Ready_for: [Next team/process]
```

## Token Efficiency Protocols

### 1. Reference-Based Communication
Instead of including full content in messages:
- Use file references: `See config/master_config.yaml:lines_45-60`
- Reference shared assets: `Using assets/palettes/klutz_primary.yaml`
- Cite prior decisions: `Following decision documented in meeting_notes_2024-01-15`

### 2. Abbreviation System
Standardized abbreviations for common terms:
- **PG** - Page/Section
- **QC** - Quality Check
- **EST** - Estimate
- **DEL** - Deliverable
- **REQ** - Requirement
- **IMP** - Implementation
- **VAL** - Validation

### 3. Batch Communication
Combine multiple updates into single messages:
```
[TEAM] [STATUS] [NORMAL] [TIME] : BATCH_UPDATE
Completed: PG5,6,7 content generation
Quality: All pages passed reading_level checks
Next: Starting PG8-10 cluster (estimated 15 min)
```

### 4. Structured Data Exchange
Use YAML/JSON for complex data instead of descriptive text:
```yaml
handoff_package:
  deliverable: "page_5_content"
  files: ["content/page5.md", "assets/page5_images/"]
  quality_metrics:
    word_count: 850
    reading_level: "grade_4"
    klutz_compliance: true
  next_steps: ["visual_design_team", "qa_review"]
```

## Coordination Protocols

### 1. Synchronization Points
**Daily Sync:** Every 50 iterations or on hour boundaries
**Milestone Sync:** At completion of major project phases
**Issue Resolution:** As needed for critical issues

### 2. Dependency Management
- Declare dependencies early with clear requirements
- Use dependency tokens for tracking inter-team handoffs
- Implement circular dependency detection and resolution

### 3. Conflict Resolution
- Priority-based conflict resolution (CRITICAL > HIGH > NORMAL > LOW)
- Resource contention resolved through orchestrator mediation
- Quality vs. timeline trade-offs documented with rationale

### 4. Knowledge Sharing
- Maintain shared decision logs for reference
- Create reusable templates for common patterns
- Document lessons learned for future projects

## Resources

### scripts/
Communication protocol implementation scripts:

**message_parser.py** - Parse and validate message formats
- Validate incoming message structure
- Extract team codes, message types, and priorities
- Route messages to appropriate handlers
- Log communications for audit trails

**status_aggregator.py** - Collect and format status updates
- Aggregate status from all teams
- Generate progress reports
- Identify bottlenecks and issues
- Calculate project metrics and KPIs

**dependency_tracker.py** - Manage inter-team dependencies
- Track task dependencies and prerequisites
- Detect circular dependencies
- Optimize task sequencing
- Generate dependency graphs

### references/
Communication protocol documentation:

**message_standards.md** - Detailed message format specifications
- Complete message format grammar
- Examples of all message types and priorities
- Error handling and validation rules
- Integration guidelines for different agent types

**coordination_patterns.md** - Team coordination workflows
- Synchronization patterns and schedules
- Dependency management procedures
- Conflict resolution strategies
- Escalation procedures and timeouts

**efficiency_guidelines.md** - Token optimization strategies
- Message optimization techniques
- Reference-based communication patterns
- Abbreviation and encoding standards
- Performance measurement guidelines

### assets/
Communication templates and configuration files:

**message_templates/** - Standardized message templates
- Status report templates for each team type
- Query and response format templates
- Issue reporting and escalation templates
- Handoff and deliverable templates

**configurations/** - Protocol configuration files
- Team-specific communication settings
- Priority level definitions and response times
- Message routing and filtering rules
- Quality of service parameters

**examples/** - Sample communication exchanges
- Typical project communication examples
- Problem scenario resolutions
- Best practice demonstrations
- Common pitfalls and solutions

## Integration Guidelines

### For Content Generation Team
- Focus on content quality and educational value metrics
- Provide detailed context for visual design requirements
- Use reading level and engagement metrics in status reports
- Reference curriculum standards and learning objectives

### For Visual Design Team
- Emphasize aesthetic compliance with 1996 Klutz Press standards
- Provide clear specifications for color and layout requirements
- Include technical constraints and file format requirements
- Reference brand guidelines and style templates

### For Technical Implementation Team
- Focus on technical feasibility and performance metrics
- Provide clear implementation requirements and constraints
- Include testing and validation procedures
- Reference technical specifications and API documentation

### For Quality Assurance Team
- Emphasize quality metrics and validation results
- Provide detailed issue reports with reproduction steps
- Include compliance checks against project standards
- Reference quality criteria and acceptance thresholds

## Usage Guidelines

### When to Use This Skill
Use this skill when:
- Coordinating communication between multiple agent teams
- Establishing standardized message formats and protocols
- Optimizing token usage in inter-agent communications
- Managing complex project dependencies and workflows

### Implementation Requirements
- All agents must follow standardized message formats
- Response times must respect priority level requirements
- Communications must be logged for audit and analysis
- Quality standards must be maintained in all exchanges

### Expected Benefits
- Reduced token usage through structured communication
- Improved coordination and reduced miscommunication
- Faster issue resolution and dependency management
- Better project visibility and progress tracking
- Enhanced quality through standardized validation