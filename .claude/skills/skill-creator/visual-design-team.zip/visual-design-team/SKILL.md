---
name: visual-design-team
description: This skill specializes in creating authentic 1996 Klutz Press visual aesthetics for Aseprite textbook workbooks, implementing period-accurate design principles, color schemes, and layout optimization for maximum educational impact and visual engagement.
---

# Visual Design Team

## Overview

This skill creates authentic 1996 Klutz Press visual design for Aseprite textbook workbooks, specializing in period-accurate aesthetics, color distribution (70/20/10), layout optimization, and visual learning elements. It focuses on token-efficient design generation through reusable templates and systematic aesthetic application.

## Core Capabilities

### 1. 1996 Klutz Press Aesthetic Implementation
Create authentic 1990s educational workbook design:
- **70/20/10 Color Distribution** - Klutz primary/Nickelodeon accent/Goosebumps theme
- **Period-Accurate Typography** - 1990s fonts and text styling
- **Layout Chaos Theory** - Calculated randomness in element placement
- **Print Simulation Artifacts** - CMYK misregistration, dot gain, vignetting

### 2. Visual Learning Optimization
Design for maximum educational effectiveness:
- **Visual Hierarchy** - Clear information organization and flow
- **Illustration Integration** - Seamless text and visual element coordination
- **Interactive Visual Elements** - Engaging design components that enhance learning
- **Age-Appropriate Visual Complexity** - Optimized for 8-14 age range

### 3. Layout and Composition Management
Optimize spatial arrangement for workbook pages:
- **Safe Zone Compliance** - Respect margins and spine dead zones
- **Two-Page Spread Design** - Coherent left-right page relationships
- **Element Rotation and Tilt** - Applied randomness within aesthetic rules
- **Texture Overlay Integration** - Paper texture and print effects

### 4. Color and Typography Systems
Manage systematic visual design elements:
- **Palette Generation** - Theme-appropriate color schemes
- **Typography Hierarchy** - Consistent text styling systems
- **Brand Consistency** - Maintain Klutz Press visual standards
- **Accessibility Compliance** - Ensure readability and visual clarity

## Visual Design Workflow

### Phase 1: Requirements Analysis
1. Parse content requirements from content generation team
2. Analyze page layout specifications and constraints
3. Identify visual hierarchy and learning objectives
4. Review technical specifications and output requirements

### Phase 2: Visual Planning
1. Create layout mockups for each page/spread
2. Establish color palettes based on content themes
3. Plan illustration integration and placement
4. Design typography hierarchy and styling systems

### Phase 3: Asset Creation
1. Generate illustrations and visual elements
2. Apply 1996 Klutz Press aesthetic treatments
3. Create text styling and formatting
4. Implement layout composition and spacing

### Phase 4: Refinement and Validation
1. Review design against 1996 period accuracy standards
2. Validate color distribution and aesthetic compliance
3. Test readability and visual hierarchy effectiveness
4. Prepare final assets for technical implementation team

## Design Systems and Templates

### 1. Color System Architecture
Implement structured color management:

**Color Distribution Framework:**
```yaml
color_system:
  primary_colors:     # 70% - Klutz foundation palette
    - klutz_red: "#FF6B6B"
    - klutz_blue: "#4ECDC4"
    - klutz_yellow: "#FFD93D"
    - klutz_green: "#6BCF7C"

  accent_colors:      # 20% - Nickelodeon energy
    - nickelodeon_orange: "#F57D0D"  # Pantone 021 C
    - secondary_accent: "#FF9F1C"

  theme_colors:       # 10% - Goosebumps special effects
    - goosebumps_green: "#95C120"
    - special_effect: "#B8E986"
```

### 2. Typography System
Structured font hierarchy and styling:

**Typography Framework:**
```yaml
typography_system:
  headers:
    main_title:
      font: "Comic_Sans_MS_Bold"
      size: "28pt"
      rotation: "±3°"
      color: "primary_colors.klutz_blue"

    section_header:
      font: "Comic_Sans_MS_Bold"
      size: "18pt"
      rotation: "±2°"
      color: "accent_colors.nickelodeon_orange"

  body_text:
    main_content:
      font: "Comic_Sans_MS"
      size: "12pt"
      color: "#333333"
      line_height: "1.4"

    captions:
      font: "Comic_Sans_MS_Italic"
      size: "10pt"
      color: "#666666"
```

### 3. Layout Grid System
Systematic page layout organization:

**Layout Framework:**
```yaml
layout_system:
  page_structure:
    canvas_size: [3400, 2200]  # Two-page spread
    safe_zones:
      left: 100px
      right: 100px
      top: 100px
      bottom: 100px
      spine: 462px  # Dead zone

    content_areas:
      main_content: "70% of usable space"
      sidebar: "20% of usable space"
      marginalia: "10% of usable space"

  element_rotation:
    text_blocks: "±5°"
    containers: "±15°"
    photos: "±10°"
    illustrations: "±8°"
```

### 4. Print Simulation System
Authentic 1990s print effect application:

**Print Effects Framework:**
```yaml
print_simulation:
  cmyk_misregistration:
    magenta_shift: [1, 0]
    yellow_shift: [0, -1]

  print_artifacts:
    dot_gain: 0.95
    vignette_strength: 0.15
    spine_shadow: 0.20
    paper_texture: "assets/textures/copy_paper_1996.png"

  color_processing:
    brightness_adjustment: -0.1
    contrast_boost: 1.1
    saturation_enhancement: 1.05
```

## Token Efficiency Strategies

### 1. Template-Based Design System
Use systematic templates for consistent, efficient design:
- Reusable layout patterns for common content types
- Standardized color palette application systems
- Pre-built typography styling frameworks
- Modular design element libraries

### 2. Reference-Based Asset Management
Minimize redundant asset creation through smart libraries:
- Shared illustration components across multiple pages
- Reusable design pattern templates
- Standardized icon and symbol libraries
- Common texture and effect overlays

### 3. Systematic Application Protocols
Apply design elements efficiently through rules-based systems:
- Automated color palette application based on content themes
- Systematic typography hierarchy application
- Rules-based layout composition and spacing
- Automated print effect application

### 4. Batch Design Processing
Generate related design elements efficiently in groups:
- Theme-based color palette families
- Sequential page layout series with consistent styling
- Age-group specific design systems
- Cross-referenced design asset families

## Resources

### scripts/
Visual design automation scripts:

**klutz_aesthetic_engine.py** - 1996 Klutz Press style application
- Apply 70/20/10 color distribution automatically
- Generate period-accurate typography styling
- Implement calculated randomness in element placement
- Apply print simulation artifacts and effects

**layout_composer.py** - Systematic layout generation
- Generate page layouts based on content requirements
- Apply safe zone constraints and spine dead zones
- Create responsive two-page spread designs
- Optimize visual hierarchy and information flow

**color_palette_generator.py** - Theme-appropriate color schemes
- Generate color palettes based on content themes
- Apply 70/20/10 distribution rules automatically
- Create accessibility-compliant color combinations
- Manage color consistency across page series

**asset_optimizer.py** - Design asset processing and optimization
- Process illustrations for print simulation effects
- Optimize assets for technical implementation requirements
- Apply consistent styling across asset families
- Generate asset variants for different use cases

### references/
Visual design reference materials:

**klutz_design_standards.md** - 1996 Klutz Press design guidelines
- Complete aesthetic rulebook and standards
- Color theory and application guidelines
- Typography principles and font usage
- Layout composition and spacing standards

**1990s_design_reference.md** - Period design authenticity guide
- 1990s design trends and cultural references
- Period-accurate color schemes and typography
- Print technology limitations and characteristics
- Age-appropriate design principles for 1990s education

**visual_learning_principles.md** - Educational design theory
- Visual hierarchy and information design
- Color psychology and learning effectiveness
- Illustration integration best practices
- Age-group visual complexity guidelines

**asset_specifications.md** - Technical design requirements
- File format specifications and standards
- Resolution and quality requirements
- Color space and profile specifications
- Asset organization and naming conventions

### assets/
Visual design templates and resources:

**layout_templates/** - Reusable page layout patterns
- Tutorial layout templates for different content types
- Activity layout frameworks with interactive elements
- Reference layout templates for informational content
- Project layout templates for multi-page sections

**color_palettes/** - Theme-appropriate color schemes
- Nickelodeon-themed color palettes
- Goosebumps-inspired color combinations
- Klutz primary color variations
- Seasonal and holiday color themes

**typography_styles/** - Font and text styling systems
- Header and title styling templates
- Body text formatting frameworks
- Caption and marginalia text styles
- Special effect text treatments

**print_textures/** - Authentic 1990s print effects
- Paper texture overlays and patterns
- CMYK misregistration effect templates
- Dot gain and print simulation filters
- Aging and wear effect libraries

## Communication Protocols

### Team Coordination
Use standardized communication for efficient collaboration:
- **[VD] [STATUS]** - Visual design progress reports
- **[VD] [QUERY]** - Requests for content specifications or technical requirements
- **[VD] [HANDOFF]** - Design assets delivery to technical implementation team
- **[VD] [ISSUE]** - Design-related blockers or technical constraints

### Dependencies Management
Coordinate effectively with other teams:
- **Content Generation Team** - Content requirements for visual design
- **Technical Implementation Team** - Asset specifications and technical constraints
- **Quality Assurance Team** - Design validation and compliance requirements
- **Orchestrator** - Timeline and resource coordination

### Quality Gates
Ensure design meets standards before handoff:
- 1996 Klutz Press aesthetic compliance verified
- Color distribution (70/20/10) validated
- Layout specifications and safe zones respected
- Assets optimized for technical implementation

## Usage Guidelines

### When to Use This Skill
Use this skill when:
- Creating visual design for Aseprite workbook pages
- Applying 1996 Klutz Press aesthetic standards
- Generating layout compositions and page designs
- Producing illustrations and visual learning elements

### Input Requirements
- Content specifications from content generation team
- Page layout requirements and constraints
- Technical specifications for asset output
- Theme and style requirements for design elements

### Expected Outputs
- Authentic 1996 Klutz Press visual design
- Optimized layout compositions for educational content
- Color-compliant design assets with proper 70/20/10 distribution
- Print-ready visual elements with period-accurate effects

### Quality Standards
- Strict adherence to 1996 Klutz Press aesthetic guidelines
- Proper color distribution and theme consistency
- Layout compliance with safe zones and spine constraints
- Visual hierarchy optimized for educational effectiveness