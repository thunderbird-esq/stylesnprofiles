---
name: content-generation-team
description: This skill specializes in AI-powered content generation for Aseprite textbook workbooks, creating engaging educational content that follows 1996 Klutz Press style while optimizing for token efficiency and parallel production workflows.
---

# Content Generation Team

## Overview

This skill enables the creation of engaging, age-appropriate educational content for Aseprite textbook workbooks, specializing in 1996 Klutz Press writing style, pixel art tutorials, and progressive learning structures. It focuses on token-efficient content generation through reusable templates and structured educational frameworks.

## Core Capabilities

### 1. Educational Content Generation
Generate workbook content with proper educational structure:
- **Progressive Learning Paths** - Building complexity from basic to advanced
- **Age-Appropriate Language** - Targeting 8-14 age range with reading levels 3-8
- **Interactive Exercises** - Hands-on pixel art tutorials and practice activities
- **Visual Learning Integration** - Text that supports and complements visual elements

### 2. 1996 Klutz Press Style Emulation
Create authentic 1990s educational content:
- **Enthusiastic Tone** - High-energy, encouraging language
- **Pop Culture References** - Appropriate 1990s references and themes
- **Hands-On Approach** - Project-based learning philosophy
- **Humor and Engagement** - Age-appropriate jokes and fun facts

### 3. Content Structuring and Organization
Organize content for maximum educational effectiveness:
- **Page-by-Page Planning** - Content mapped to specific workbook pages
- **Learning Objective Alignment** - Content tied to specific educational goals
- **Cross-Reference Systems** - Links between related sections and concepts
- **Progress Tracking Integration** - Built-in assessment and milestone markers

### 4. Quality and Consistency Management
Ensure high-quality content production:
- **Reading Level Validation** - Automated verification of age-appropriateness
- **Educational Standard Compliance** - Alignment with curriculum guidelines
- **Content Consistency Checks** - Maintaining style and quality across sections
- **Fact-Checking and Validation** - Verification of technical accuracy

## Content Generation Workflow

### Phase 1: Requirements Analysis
1. Parse project specifications from master_config.yaml
2. Identify target age group and skill level requirements
3. Analyze page layout constraints and space limitations
4. Review cross-team dependencies (visual design, technical requirements)

### Phase 2: Content Planning
1. Create detailed content outline for assigned pages/sections
2. Establish learning objectives and success criteria
3. Plan interactive elements and practice exercises
4. Identify visual content requirements for coordination with design team

### Phase 3: Content Generation
1. Generate primary content using AI models and templates
2. Create interactive exercises and activities
3. Add engaging elements (humor, facts, cultural references)
4. Ensure proper educational progression and scaffolding

### Phase 4: Refinement and Validation
1. Review content for educational effectiveness
2. Validate reading levels and age appropriateness
3. Check alignment with 1996 Klutz Press style guidelines
4. Prepare content for handoff to visual design team

## Content Types and Templates

### 1. Tutorial Content
Structured step-by-step instructions for pixel art techniques:

**Template Structure:**
```yaml
tutorial:
  title: "Catchy, action-oriented title"
  introduction: "Hook with engaging scenario"
  learning_objectives: ["Clear, measurable goals"]
  steps:
    - step_number: 1
      instruction: "Clear, concise action"
      visual_note: "Description of needed illustration"
      tip: "Helpful hint or encouragement"
  practice_exercise: "Application activity"
  challenge_extension: "Optional advanced variation"
```

### 2. Reference Content
Informative sections about tools, techniques, and concepts:

**Template Structure:**
```yaml
reference:
  topic: "Clear subject heading"
  definition: "Simple, accurate explanation"
  examples: ["Concrete, relatable examples"]
  applications: ["Practical uses in pixel art"]
  fun_fact: "Engaging trivia or interesting information"
```

### 3. Activity Content
Interactive exercises and hands-on projects:

**Template Structure:**
```yaml
activity:
  name: "Exciting activity title"
  duration: "Time estimate in minutes"
  materials: ["List of required supplies"]
  instructions: ["Step-by-step directions"]
  learning_outcome: "Expected result or skill"
  reflection_prompt: "Questions for self-assessment"
```

### 4. Project Content
Multi-page projects that combine multiple skills:

**Template Structure:**
```yaml
project:
  title: "Impressive project name"
  overview: "Exciting project description"
  skills_covered: ["List of techniques learned"]
  pages_required: "Number of pages for completion"
  steps: ["Major project phases"]
  showcase_instructions: "How to display finished work"
```

## Token Efficiency Strategies

### 1. Template-Based Generation
Use structured templates for consistent, efficient content creation:
- Reusable content patterns for common tutorial structures
- Standardized educational frameworks for learning objectives
- Pre-built engagement elements (jokes, facts, cultural references)
- Modular content blocks that can be combined efficiently

### 2. Reference-Based Content
Minimize redundant content through smart referencing:
- Common technique explanations referenced rather than repeated
- Shared tool descriptions across multiple sections
- Standardized character and theme references
- Consolidated glossaries and reference sections

### 3. Progressive Disclosure
Provide information efficiently through layered content:
- Basic instructions upfront, advanced tips as needed
- Optional extensions for advanced students
- Supplemental information in sidebars and callouts
- Multi-level content for different skill levels

### 4. Batch Processing
Generate related content efficiently in groups:
- Theme-based content clusters (e.g., all "color theory" sections)
- Sequential tutorial series with shared elements
- Age-group specific content with consistent complexity
- Cross-referenced content families

## Resources

### scripts/
Content generation automation scripts:

**content_generator.py** - AI-powered content creation
- Interface with Google Generative AI for content generation
- Apply 1996 Klutz Press style templates
- Validate reading levels and educational appropriateness
- Generate content variations for A/B testing

**tutorial_builder.py** - Structured tutorial creation
- Build step-by-step tutorials from content specifications
- Generate practice exercises and assessments
- Create progressive learning sequences
- Integrate with visual design requirements

**content_validator.py** - Quality assurance automation
- Check reading levels using standard metrics
- Validate educational content alignment
- Verify 1996 period accuracy and cultural references
- Ensure content consistency across sections

### references/
Content generation reference materials:

**klutz_style_guide.md** - 1996 Klutz Press writing standards
- Tone and voice guidelines
- Age-appropriate language standards
- Humor and engagement principles
- Cultural reference guidelines for 1990s content

**educational_frameworks.md** - Learning theory and standards
- Progressive learning methodologies
- Age-group educational standards
- Interactive learning principles
- Assessment and feedback strategies

**content_templates.md** - Reusable content patterns
- Tutorial structures and templates
- Activity frameworks and patterns
- Reference content organization
- Project planning templates

**pixel_art_curriculum.md** - Technical content references
- Aseprite tool documentation and tutorials
- Pixel art technique explanations
- Art principles for digital creation
- Common project types and examples

### assets/
Content templates and resource files:

**content_templates/** - Reusable content structures
- Tutorial templates for different skill levels
- Activity templates for various interaction types
- Reference content templates for common topics
- Project planning templates and frameworks

**writing_samples/** - 1996 Klutz Press examples
- Sample pages and content for style reference
- Age-appropriate writing examples
- Effective tutorial structures
- Engaging educational content samples

**educational_resources/** - Learning support materials
- Reading level assessment tools
- Educational standards alignment guides
- Learning objective frameworks
- Assessment and evaluation templates

## Communication Protocols

### Team Coordination
Use standardized communication for efficient collaboration:
- **[CG] [STATUS]** - Content generation progress reports
- **[CG] [QUERY]** - Requests for visual design specifications
- **[CG] [HANDOFF]** - Content delivery to visual design team
- **[CG] [ISSUE]** - Content-related blockers or problems

### Dependencies Management
Coordinate effectively with other teams:
- **Visual Design Team** - Content requirements for illustrations
- **Technical Implementation Team** - Content technical specifications
- **Quality Assurance Team** - Content validation and review requirements
- **Orchestrator** - Timeline and resource coordination

### Quality Gates
Ensure content meets standards before handoff:
- Reading level validation complete
- Educational objectives clearly defined
- 1996 Klutz Press style compliance verified
- Cross-team requirements identified and communicated

## Usage Guidelines

### When to Use This Skill
Use this skill when:
- Creating educational content for Aseprite workbooks
- Generating tutorials and interactive learning materials
- Developing age-appropriate content for 8-14 age range
- Producing content that matches 1996 Klutz Press style

### Input Requirements
- Clear page specifications and space constraints
- Target age group and skill level definitions
- Learning objectives and educational goals
- Visual design requirements and constraints

### Expected Outputs
- Engaging, educational content matching 1990s style
- Age-appropriate text with proper reading levels
- Structured tutorials and interactive activities
- Content ready for visual design team integration

### Quality Standards
- Reading level appropriate for target age group
- Alignment with educational best practices
- Consistency with 1996 Klutz Press style
- Clear learning objectives and assessment criteria