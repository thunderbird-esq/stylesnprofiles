---
name: workbook-team-orchestrator
description: This skill orchestrates parallel teams of specialized agents for Aseprite textbook generation, managing team coordination, task distribution, and communication protocols for maximum token efficiency and parallel execution.
---

# Workbook Team Orchestrator

## Overview

This skill enables the orchestration of multiple parallel agent teams for Aseprite textbook generation, providing token-efficient coordination through structured communication protocols, task distribution, and team management. It serves as the central nervous system for content generation, visual design, technical implementation, and quality assurance teams.

## Core Capabilities

### 1. Team Orchestration
Manage parallel execution of specialized agent teams:
- **Content Generation Team** - AI-powered workbook content creation
- **Visual Design Team** - 1996 Klutz Press aesthetic implementation
- **Technical Implementation Team** - Python code and image processing
- **Quality Assurance Team** - Validation and testing workflows

### 2. Task Distribution System
Optimize token efficiency through intelligent task allocation:
- Analyze project requirements and distribute to appropriate teams
- Create parallel task pipelines for maximum throughput
- Manage dependencies and task sequencing
- Balance workload across available agents

### 3. Communication Protocol Management
Implement standardized agent communication patterns:
- Use `communication-protocols` skill for consistent messaging
- Maintain shared context through reference libraries
- Minimize redundant information exchange
- Enable efficient handoffs between teams

### 4. Resource Coordination
Manage shared resources and configurations:
- Access project configuration via `config/master_config.yaml`
- Coordinate access to AI models and APIs
- Manage temporary files and intermediate outputs
- Optimize resource utilization across teams

## Orchestration Workflow

### Phase 1: Project Analysis
1. Parse project requirements from user input
2. Analyze existing project structure and configuration
3. Identify required team capabilities and dependencies
4. Create project execution plan with task breakdown

### Phase 2: Team Activation
1. Launch appropriate specialized agent teams in parallel
2. Provide teams with specific task assignments and context
3. Establish communication channels and reporting protocols
4. Set up progress monitoring and quality checkpoints

### Phase 3: Parallel Execution
1. Monitor team progress through standardized status updates
2. Manage inter-team dependencies and data flow
3. Resolve conflicts and resource contention
4. Maintain project timeline and quality standards

### Phase 4: Integration and Delivery
1. Collect outputs from all teams
2. Perform final integration and validation
3. Generate comprehensive delivery report
4. Archive project artifacts and lessons learned

## Team Coordination Commands

### Launching Teams
Use specific agent task delegation for team activation:
```bash
# Launch content generation team
Task: content-generation-workflow
Subagent_type: general-purpose
Parameters: { "task": "generate_workbook_content", "pages": 1-20 }

# Launch visual design team
Task: visual-design-workflow
Subagent_type: computer-vision-engineer
Parameters: { "task": "apply_klutz_aesthetic", "style": "1996" }

# Launch technical implementation team
Task: technical-implementation-workflow
Subagent_type: python-pro
Parameters: { "task": "implement_image_processing", "quality": "production" }

# Launch quality assurance team
Task: quality-assurance-workflow
Subagent_type: test-engineer
Parameters: { "task": "validate_workbook", "standards": "klutz_press" }
```

### Monitoring Progress
Use structured progress queries:
- Request status updates from each team every N iterations
- Validate milestone completion before proceeding
- Monitor token usage and execution efficiency
- Track quality metrics and error rates

### Managing Dependencies
Handle inter-team task dependencies:
- Identify prerequisite tasks across teams
- Create dependency graphs and critical paths
- Schedule parallel execution where possible
- Manage data handoffs and integration points

## Resources

### scripts/
Executable orchestration scripts for team management:

**team_launcher.py** - Automated team activation script
- Parses project requirements
- Launches appropriate agent teams
- Sets up communication protocols
- Monitors resource utilization

**progress_monitor.py** - Real-time progress tracking
- Collects status updates from all teams
- Generates progress reports
- Identifies bottlenecks and issues
- Estimates completion times

**integration_coordinator.py** - Output integration management
- Collects and validates team outputs
- Performs final integration steps
- Generates delivery packages
- Archives project artifacts

### references/
Orchestration documentation and protocols:

**team_protocols.md** - Team coordination guidelines
- Standard operating procedures for each team
- Communication templates and formats
- Quality standards and validation criteria
- Escalation procedures and issue handling

**execution_patterns.md** - Common execution workflows
- Typical project patterns and solutions
- Dependency management strategies
- Resource optimization techniques
- Risk mitigation approaches

**communication_standards.md** - Inter-team communication protocols
- Message formats and structures
- Status reporting requirements
- Data exchange specifications
- Conflict resolution procedures

### assets/
Orchestration templates and configuration files:

**project_templates/** - Common project structures
- Workbook generation templates
- Team assignment templates
- Progress tracking templates
- Delivery report templates

**configurations/** - Orchestration settings
- Team configuration presets
- Resource allocation settings
- Quality threshold configurations
- Communication protocol settings

## Token Efficiency Strategies

### 1. Context Optimization
- Share common references across teams to eliminate redundancy
- Use asset templates instead of generating repetitive content
- Implement progressive disclosure of detailed information
- Cache frequently accessed configurations and protocols

### 2. Communication Efficiency
- Use structured message formats to minimize parsing overhead
- Implement status abbreviations and standardized responses
- Batch communications where possible
- Use references instead of inline detailed explanations

### 3. Parallel Execution Optimization
- Identify and eliminate sequential bottlenecks
- Create independent task streams for maximum parallelism
- Optimize team sizes based on task complexity
- Implement load balancing across available agents

### 4. Resource Management
- Pre-allocate resources to avoid contention delays
- Use shared templates and libraries effectively
- Implement efficient data handoff protocols
- Optimize API usage and caching strategies

## Usage Guidelines

### When to Use This Skill
Use this skill when:
- Generating complete Aseprite workbooks requiring multiple expertise areas
- Coordinating complex projects with interdependent components
- Managing parallel agent teams for maximum efficiency
- Implementing quality-controlled production workflows

### Prerequisites
- Ensure all required team skills are available
- Verify project configuration is complete and valid
- Confirm resource availability and access permissions
- Establish quality standards and validation criteria

### Expected Outputs
- Coordinated team execution with minimal overhead
- High-quality workbook generation meeting all specifications
- Comprehensive progress tracking and reporting
- Efficient resource utilization and token management

## Integration with Other Skills

This skill orchestrates and coordinates with:
- `content-generation-team` - For workbook content creation
- `visual-design-team` - For aesthetic implementation
- `technical-implementation-team` - For code and processing
- `quality-assurance-team` - For validation and testing
- `communication-protocols` - For standardized messaging